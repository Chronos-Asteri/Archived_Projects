# Text Gradient animation (Vercel style)

A Pen created on CodePen.io. Original URL: [https://codepen.io/abjt14/pen/NWYPEKW](https://codepen.io/abjt14/pen/NWYPEKW).

Using hue-rotate to create gradient animation. Inspired by Vercel's website.

Reference: https://vercel.com/